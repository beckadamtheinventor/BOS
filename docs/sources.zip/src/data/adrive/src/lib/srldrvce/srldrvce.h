/**
 * @file
 * @author
 * @brief USB Serial Host Driver
 */

#ifndef H_SRLDRVCE
#define H_SRLDRVCE

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif
