
import os,json

def build(fname, cache, props):
	with open(fname, "rb") as f:
		data = f.read()
		h = str(hash(data))
		if fname in cache.keys():
			if cache[fname]["hash"] == h and len(data) == cache[fname]["len"]:
				return
	cache[fname] = {"hash": h, "len": len(data)}
	bname = fname.replace("srcfs/","fs/")
	if fname.endswith("._asm"):
		print("assembling",fname)
		n=f"temp/{os.path.basename(fname)}.temp"
		with open(n,"wb") as f:
			if b"include '../include/library.inc'" not in data:
				f.write(b"include '../include/ez80.inc'\ninclude '../include/ti84pceg.inc'\ninclude '../include/bos.inc'\n")
			f.write(data)
		bname = f"{bname[:-5]}.bin"
		if fname in props.keys():
			if "bin" in props[fname]:
				bname = props[fname]["bin"]
		os.system(f"fasmg {n} {bname}")
	elif not fname.endswith(".unused"):
		with open(bname,"wb") as f:
			f.write(data)

def fwalk(path):
	f=[]
	d=[]
	for root,dirs,files in os.walk(path):
		d.append(root+"/")
		for n in files:
			f.append(root+"/"+n)
	return f,d

usable_filename_chars = "/._0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

if __name__=='__main__':
	try:
		os.makedirs("temp")
	except OSError:
		pass
	#open the hash cache
	try:
		with open("cache.json") as f:
			cache = json.load(f)
	except:
		cache = {}
	#open file and directory properties
	try:
		with open("properties.json") as f:
			props = json.load(f)
	except:
		props = {}

	#get all files and directories in the source directory
	files, dirs = fwalk("srcfs/")

	#check file names for illegal characters
	for f in dirs+files:
		if any([c not in usable_filename_chars for c in f]):
			print('Error: file "{d}" contains unsuitable characters in the file name.\nUsable characters: "{usable_filename_chars}"')
			exit(1)

	#copy directories
	for d in dirs:
		if d in props.keys():
			if "ignore" in props[d]:
				if props[d]["ignore"]:
					continue
		try:
			os.makedirs(d.replace("srcfs/", "fs/"))
		except OSError:
			pass

	#build & copy files
	for f in files:
		if f in props.keys():
			if "ignore" in props[f]:
				if props[f]["ignore"]:
					continue
		build(f, cache, props)

	#save the hash cache
	with open("cache.json", "w") as f:
		json.dump(cache, f)


	#get all files and directories in the filesystem directory
	files, dirs = fwalk("fs")

	#process directories
	output_dirs = {}
	for d in dirs:
		properties = 0
		if d in props.keys():
			if "flags" in props[d].keys():
				properties = props[d]["flags"]
		a = d.rstrip("/").rsplit("/", maxsplit=1)
		if len(a) < 2:
			parent, child = "root", a[0]
		else:
			parent, child = a
		parent = parent.replace("fs","root",1).rstrip("/").replace("/",".")
		if not len(parent):
			parent = "root"
		if not len(child):
			child = "root"
		if parent not in output_dirs.keys():
			output_dirs[parent] = [f"fs_dir dirs.{parent}\n"]
		if child not in output_dirs.keys():
			output_dirs[child] = [f"fs_file dirs.{parent}.{child}\n"]
		output_dirs[parent].append(f'\tfs_entry dirs.{parent}.{child}, "{child}", "", f_subdir+{properties}\n')

	#process files
	output_files = {}
	for f in files:
		properties = 0
		if f in props.keys():
			if "flags" in props[f].keys():
				properties = props[f]["flags"]
		a = f.rstrip("/").rsplit("/", maxsplit=1)
		if len(a) < 2:
			parent, child = "root", a[0]
		else:
			parent, child = a
		parent = parent.replace("fs","root",1).rstrip("/").replace("/",".")
		if "." in child:
			name, ext = child.rsplit(".",maxsplit=1)
		else:
			name = child
			ext = ""
		if len(name)>8 or len(ext)>3:
			print("File names can be a maximum of 8 characters, extensions a maximum of 3 characters.")
			exit(1)
		if len(name):
			output_dirs[parent].append(f'\tfs_entry files.{child}, "{name}", "{ext}", {properties}\n')
		if f not in output_files.keys():
			output_files[f] = [f"fs_file files.{child}\n\tfile '{f}'\nend fs_file\n\n"]

	#write the data
	with open("main.asm","w") as fd:
		fd.write("""
include '../include/bosfs.inc'
fs_fs
fs_dir root_of_roots
	fs_entry dirs.root, "bosfs512", "fs", f_subdir+f_readonly+f_system
end fs_dir
""")
		for d in output_dirs.keys():
			fd.write("".join(output_dirs[d]))
			fd.write("\nend fs_dir\n\n")
		for f in output_files.keys():
			fd.write("".join(output_files[f]))
		fd.write("\n\nend fs_fs\n")

	#assemble and compress the data
	os.system("fasmg main.asm fs.bin")
	os.system("convbin -i fs.bin -o fs_compressed.bin -j bin -k bin -c zx7")



