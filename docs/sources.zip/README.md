# BOS
An Operating system (WIP) for the TI-84+CE family (eZ80) graphing calculators

# Building on Linux/Mac/Unix
Run the provided `build.sh` file in bash, and the binary will be in the `bin` folder.

# Building on Windows
Run the provided `build.bat` file, and the binary will be in the `bin` folder.

